import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:loginpage/pages/ProfileForOthers.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class FriendChatPage extends StatefulWidget {
  final String friendId;
  final String friendUsername;
  final String? friendAvatarUrl;

  const FriendChatPage({
    super.key,
    required this.friendId,
    required this.friendUsername,
    this.friendAvatarUrl,
  });

  @override
  State<FriendChatPage> createState() => _FriendChatPageState();
}

class _FriendChatPageState extends State<FriendChatPage> {
  final supabase = Supabase.instance.client;
  final TextEditingController _controller = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  List<Map<String, dynamic>> messages = [];
  RealtimeChannel? _channel;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _initChat();
  }

  Future<void> _initChat() async {
    await _loadMessages();
 
    _subscribeMessages();

    setState(() {
      isLoading = false;
    });

    _scrollToBottom();
  }

  Future<void> _loadMessages() async {
  final currentUserId = supabase.auth.currentUser!.id;

  final response = await supabase
      .from('friends_messages')
      .select('id, message, sender_id, receiver_id, created_at, sender:sender_id(id, username, avatar_url)')
      .or(
        'and(sender_id.eq.$currentUserId,receiver_id.eq.${widget.friendId}),and(sender_id.eq.${widget.friendId},receiver_id.eq.$currentUserId)',
      )
      .order('created_at', ascending: true);

  if (response != null) {
    setState(() {
      messages = List<Map<String, dynamic>>.from(response);
      isLoading = false; // ✅ direkt hier fertig laden
    });
  }
}


  

  void _subscribeMessages() {
    final currentUserId = supabase.auth.currentUser!.id;

    _channel = supabase.channel('friend_chat_${widget.friendId}')
      ..onPostgresChanges(
        event: PostgresChangeEvent.insert,
        schema: 'public',
        table: 'friends_messages',
        callback: (payload) {
          final newMsg = payload.newRecord;
          final senderId = newMsg['sender_id'];
          final receiverId = newMsg['receiver_id'];

          if ((senderId == currentUserId && receiverId == widget.friendId) ||
              (senderId == widget.friendId && receiverId == currentUserId)) {
            setState(() {
              messages.add(newMsg);
            });
            _scrollToBottom();
          }
        },
      )
      ..subscribe();
  }

  Future<void> _sendMessage() async {
    final currentUserId = supabase.auth.currentUser!.id;
    final text = _controller.text.trim();
    if (text.isEmpty) return;

    await supabase.from('friends_messages').insert({
      'sender_id': currentUserId,
      'receiver_id': widget.friendId,
      'message': text,
    });

    _controller.clear();
    _scrollToBottom();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          0,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: GestureDetector(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => PublicProfilePage(userId: widget.friendId),
              ),
            );
          },
          child: Row(
            children: [
              CircleAvatar(
                radius: 18,
                backgroundColor: Colors.grey[300],
                backgroundImage: (widget.friendAvatarUrl != null &&
                        widget.friendAvatarUrl!.isNotEmpty)
                    ? NetworkImage(widget.friendAvatarUrl!)
                    : null,
                child: (widget.friendAvatarUrl == null ||
                        widget.friendAvatarUrl!.isEmpty)
                    ? const Icon(Icons.person, color: Colors.white)
                    : null,
              ),
              const SizedBox(width: 10),
              Text(widget.friendUsername),
            ],
          ),
        ),
      ),

      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: isLoading
                  ? const Center(child: CircularProgressIndicator())
                  : ListView.builder(
                      controller: _scrollController,
                      reverse: true,
                      itemCount: messages.length,
                      itemBuilder: (context, index) {
                        final message = messages[messages.length - 1 - index];
                        final isMe =
                            message['sender_id'] == supabase.auth.currentUser!.id;
                        return Align(
                          alignment: isMe
                              ? Alignment.centerRight
                              : Alignment.centerLeft,
                          child: Container(
                            margin: const EdgeInsets.symmetric(
                                horizontal: 12.0, vertical: 4.0),
                            padding: const EdgeInsets.all(12.0),
                            decoration: BoxDecoration(
                              color: isMe ? Colors.blue[200] : Colors.grey[300],
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Column(
                              crossAxisAlignment: isMe
                                  ? CrossAxisAlignment.end
                                  : CrossAxisAlignment.start,
                              children: [
                                Text(
                                  message['message'],
                                  style: const TextStyle(fontSize: 16),
                                ),
                                const SizedBox(height: 4),
                                if (message['sender'] != null)
                                  Text(
                                    message['sender']['username'],
                                    style: const TextStyle(
                                        fontSize: 12, color: Colors.grey),
                                  ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),
            Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 8.0, vertical: 4.0),
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.primary,
                        border: Border.all(
                            color: Theme.of(context).colorScheme.inversePrimary),
                        borderRadius: BorderRadius.circular(100.0),
                      ),
                      padding: const EdgeInsets.symmetric(horizontal: 16.0),
                      child: TextField(
                        controller: _controller,
                        decoration: const InputDecoration(
                          hintText: 'Schreibe eine Nachricht...',
                          border: InputBorder.none,
                        ),
                        onSubmitted: (_) => _sendMessage(),
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.send),
                    color: Theme.of(context).colorScheme.inversePrimary,
                    onPressed: _sendMessage,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
