import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:loginpage/components/EventMap.dart';
import 'package:loginpage/components/event_creation_sheet.dart';
import 'package:loginpage/components/event_detail_sheet.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:modal_bottom_sheet/modal_bottom_sheet.dart';

class EventsTab extends StatefulWidget {
  const EventsTab({super.key});

  @override
  _EventsTabState createState() => _EventsTabState();
}

class _EventsTabState extends State<EventsTab> {
  List<Map<String, dynamic>> events = [];

  Future<void> _fetchEvents() async {
    final response = await Supabase.instance.client
        .from('events')
        .select(
          'id, title, description, location_name, latitude, longitude, sport, max_participants, current_participants, created_at, image_urls',
        )
        .order('created_at', ascending: false);

    if (response == null) return;

    // Parsing image_urls aus JSON-String zu List<String>
    List<Map<String, dynamic>> parsedEvents = [];
    for (final event in response) {
      Map<String, dynamic> ev = Map<String, dynamic>.from(event);
      final rawImages = ev['image_urls'];
      List<String> imageUrls = [];

      if (rawImages != null) {
        try {
          if (rawImages is String) {
            imageUrls = List<String>.from(jsonDecode(rawImages));
          } else if (rawImages is List) {
            imageUrls = List<String>.from(rawImages);
          }
        } catch (_) {
          imageUrls = [];
        }
      }
      ev['image_urls'] = imageUrls;
      parsedEvents.add(ev);
    }

    setState(() {
      events = parsedEvents;
    });
  }

  @override
  void initState() {
    super.initState();
    _fetchEvents();
  }

  void showCreateEventBottomSheet(BuildContext context) {
    showCupertinoModalBottomSheet(
      context: context,
      expand: true,
      topRadius: const Radius.circular(20),
      builder: (context) => const EventCreationSheet(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 30.0),
        child: Column(
          children: [
            Align(
              alignment: Alignment.topLeft,
              child: Text(
                'Hier werden deine Events angezeigt.',
                style: TextStyle(
                  fontWeight: FontWeight.w500,
                  color: Theme.of(context).colorScheme.inversePrimary,
                  fontSize: 15,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: events.isEmpty
                  ? Center(
                      child: Text(
                        'Keine Events gefunden.',
                        style: TextStyle(
                          color: Theme.of(context).colorScheme.inversePrimary,
                          fontSize: 18,
                        ),
                      ),
                    )
                  : ListView.builder(
                      itemCount: events.length,
                      itemBuilder: (context, index) {
                        final event = events[index];
                        return Card(
                          margin: const EdgeInsets.symmetric(vertical: 10.0),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10.0),
                            side: BorderSide(
                              color: Theme.of(context).colorScheme.primary,
                              width: 1.0,
                            ),
                          ),
                          child: ListTile(
                            title: Text(event['title']),
                            subtitle: Text(event['description']),
                            trailing: Text(event['sport']),
                            onTap: () {
                              showCupertinoModalBottomSheet(
                                context: context,
                                expand: true,
                                builder: (context) => EventDetailSheet(
                                  event: event,
                                  onJoin: () async {
                                    final userId = Supabase.instance.client.auth.currentUser?.id;
                                    if (userId == null) {
                                      ScaffoldMessenger.of(context).showSnackBar(
                                        const SnackBar(content: Text('Bitte einloggen.')),
                                      );
                                      return;
                                    }

                                    final eventId = event['id'];

                                    final existing = await Supabase.instance.client
                                        .from('event_participants')
                                        .select()
                                        .eq('event_id', eventId)
                                        .eq('user_id', userId);

                                    if ((existing as List).isNotEmpty) {
                                      ScaffoldMessenger.of(context).showSnackBar(
                                        const SnackBar(content: Text('Du bist bereits angemeldet.')),
                                      );
                                      return;
                                    }

                                    await Supabase.instance.client.from('event_participants').insert({
                                      'event_id': eventId,
                                      'user_id': userId,
                                    });

                                    Navigator.of(context).pop();
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(content: Text('Beigetreten!')),
                                    );

                                    await _fetchEvents();
                                  },
                                ),
                              );
                            },
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => showCreateEventBottomSheet(context),
        child: Icon(
          Icons.add,
          color: Theme.of(context).colorScheme.inversePrimary,
        ),
      ),
    );
  }
}
