import 'package:flutter/material.dart';
import 'package:loginpage/pages/ProfileForOthers.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:loginpage/pages/events_tab.dart';

class MySearch extends StatefulWidget {
  const MySearch({super.key});

  @override
  State<MySearch> createState() => _MySearchState();
}

class _MySearchState extends State<MySearch> {
  final TextEditingController searchController = TextEditingController();
  List<dynamic> searchResults = [];
  bool isLoading = false;

  Future<void> searchUsers() async {
    final query = searchController.text.trim();

    if (query.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Bitte einen Suchbegriff eingeben.')),
      );
      return;
    }

    setState(() => isLoading = true);

    try {
      final response = await Supabase.instance.client
          .from('profiles')
          .select('id, username, avatar_url, display_name')
          .ilike('username', '%$query%');

      setState(() {
        searchResults = response;
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Fehler bei der Suche: $e')),
      );
    } finally {
      setState(() => isLoading = false);
    }
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

@override
Widget build(BuildContext context) {
  return DefaultTabController(
    length: 2,
    child: Scaffold(
      backgroundColor: Theme.of(context).colorScheme.surface,
      body: Stack(
        children: [
          Positioned(
              top: 58,
              left: 30,
              child: Text(
                'tgthr.',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                  color: Theme.of(context).colorScheme.inversePrimary,
                ),
              ),
            ),
        
      
      SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 75),

            // Überschrift
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 30.0),
              child: Text(
                'Finden',
                style: TextStyle(
                  fontWeight: FontWeight.w900,
                  color: Theme.of(context).colorScheme.inversePrimary,
                  fontSize: 30,
                ),
              ),
            ),

            // Darunter: Tabs
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 30.0),
              child: TabBar(
                tabs: [
                  Tab(text: 'Personen'),
                  Tab(text: 'Ereignisse'),
                ],
                labelColor: Theme.of(context).colorScheme.inversePrimary,
                unselectedLabelColor: Colors.grey,
                indicatorColor: Theme.of(context).colorScheme.inversePrimary,
                labelStyle: TextStyle(fontWeight: FontWeight.bold),
              ),
            ),

            const SizedBox(height: 20),

            // Inhalte der Tabs
            Expanded(
              child: TabBarView(
                children: [
                  buildUserSearchTab(),
                  const EventsTab(),
                ],
              ),
            ),
          ],
        ),
      ),
     ],
      ),
    ),
  );
}


  // TAB 1: Benutzer finden
  Widget buildUserSearchTab() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 30.0),
          child: Align(
            alignment: Alignment.centerLeft,
            child: Text(
              'Finde Trainingspartner und Aktivitäten',
              style: TextStyle(
                fontWeight: FontWeight.w500,
                color: Theme.of(context).colorScheme.inversePrimary,
                fontSize: 15,
              ),
            ),
          ),
        ),
        const SizedBox(height: 20),
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: TextField(
            controller: searchController,
            decoration: InputDecoration(
              labelText: 'Eindeutigen Nutzernamen suchen',
              border: const OutlineInputBorder(),
              suffixIcon: IconButton(
                icon: const Icon(Icons.search),
                onPressed: searchUsers,
              ),
            ),
            onSubmitted: (_) => searchUsers(),
          ),
        ),
        const SizedBox(height: 20),
        if (isLoading)
          const Center(child: CircularProgressIndicator())
        else if (searchResults.isEmpty)
          const Text('Keine Nutzer gefunden.')
        else
          Expanded(
            child: ListView.builder(
              itemCount: searchResults.length,
              itemBuilder: (context, index) {
                final user = searchResults[index];
                final avatarUrl = user['avatar_url'];
                return Card(
                  child: ListTile(
                    leading: avatarUrl != null && avatarUrl != ''
                        ? CircleAvatar(
                            backgroundImage: NetworkImage(avatarUrl),
                            radius: 20,
                          )
                        : const CircleAvatar(
                            child: Icon(Icons.person),
                            radius: 20,
                          ),
                    title:
                        Text('${user['display_name'] ?? user['username']}'),
                    subtitle: Text('@${user['username']}'),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) =>
                              PublicProfilePage(userId: user['id']),
                        ),
                      );
                    },
                  ),
                );
              },
            ),
          ),
      ],
    );
  }

}
