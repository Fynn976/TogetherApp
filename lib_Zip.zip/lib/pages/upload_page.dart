import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:loginpage/components/bottom_nav_bar.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class MyUpload extends StatefulWidget {
  const MyUpload({super.key});

  @override
  State<MyUpload> createState() => _MyUploadState();
}

class _MyUploadState extends State<MyUpload> {
  File?_imageFile;

  final captionController = TextEditingController();

  void caption() async {
    final caption = captionController.text;
    if (caption.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Bitte eine Bildbeschreibung eingeben")),
      );
      return;
    }
    // You can add further logic here if needed
  }
  

  // pick image
  Future pickImage() async {
    final ImagePicker picker = ImagePicker();
    final XFile? image = await picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      setState(() {
        _imageFile = File(image.path);
      });
    }
  }

  // upload image
  Future uploadImage() async {
    if (_imageFile == null) return;

    final caption = captionController.text;
    final fileName = DateTime.now().millisecondsSinceEpoch.toString();
    final path = 'uploads/$fileName.jpg';

    try {
      await Supabase.instance.client.storage
          .from('images')
          .upload(path, _imageFile!);

      final imageUrl = Supabase.instance.client.storage
          .from('images')
          .getPublicUrl(path);

      final user = Supabase.instance.client.auth.currentUser;
      if (user == null) {
        throw Exception('Kein Benutzer eingeloggt');
      }

      final userId = user.id;

      await Supabase.instance.client.from('posts').insert({
        'image_url': imageUrl,
        'user_id': userId,
        'created_at': DateTime.now().toIso8601String(),
        'caption': caption,
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Bild erfolgreich hochgeladen!')),
      );

      setState(() {
        _imageFile = null;
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Fehler beim Hochladen: ${e.toString()}')),
      );
    }
  }

  // upload video
  // Add your video upload logic here if needed

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.surface,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Stack(
            children: [
              Center(
                child: Column(
                  children: [
                    const SizedBox(height: 25),
                    Padding(
                      padding: const EdgeInsets.only(left: 30.0, top: 50),
                      child: Row(
                        children: [
                          Text(
                            'Hochladen',
                            style: TextStyle(
                              fontWeight: FontWeight.w900,
                              color: Theme.of(context).colorScheme.inversePrimary,
                              fontSize: 30,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 10),
                    Padding(
                      padding: const EdgeInsets.only(left: 30.0),
                      child: Row(
                        children: [
                          Text(
                            'Lade neue Inhalte hoch',
                            style: TextStyle(
                              fontWeight: FontWeight.w500,
                              color: Theme.of(context).colorScheme.inversePrimary,
                              fontSize: 15,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 100),
                    _imageFile != null
                        ? Image.file(_imageFile!)
                        : Text(
                            'Kein Bild ausgewählt',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                              color: Theme.of(context).colorScheme.inversePrimary,
                            ),
                          ),
                    const SizedBox(height: 20),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16.0),
                      child: TextField(
                        controller: captionController,
                        decoration: InputDecoration(
                          labelText: 'Bildbeschreibung',
                          border: const OutlineInputBorder(),
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    ElevatedButton(
                      onPressed: () {
                        pickImage();
                      },
                      child: Text(
                        'Bild auswählen',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                          color: Theme.of(context).colorScheme.inversePrimary,
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    ElevatedButton(
                      onPressed: () {
                        uploadImage();
                      },
                      child: Text(
                        'Bild hochladen',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                          color: Theme.of(context).colorScheme.inversePrimary,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Positioned(
                top: 20,
                left: 30,
                child: Text(
                  'tgthr.',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                    color: Theme.of(context).colorScheme.inversePrimary,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}