import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class PublicProfilePage extends StatefulWidget {
  final String userId;

  const PublicProfilePage({super.key, required this.userId});

  @override
  State<PublicProfilePage> createState() => _PublicProfilePageState();
}

class _PublicProfilePageState extends State<PublicProfilePage> {
  Map<String, dynamic>? profileData;
  List<dynamic> userPosts = [];

  @override
  void initState() {
    super.initState();
    loadProfile();
    fetchUserPosts();
  }

  Future<void> loadProfile() async {
    final response = await Supabase.instance.client
        .from('profiles')
        .select('username, avatar_url, favorite_sport')
        .eq('id', widget.userId)
        .maybeSingle();

    setState(() {
      profileData = response;
    });
  }

  Future<void> fetchUserPosts() async {
    final response = await Supabase.instance.client
        .from('posts')
        .select('id, image_url, created_at')
        .eq('user_id', widget.userId)
        .order('created_at', ascending: false);

    setState(() {
      userPosts = response;
    });
  }

  Future<void> sendFriendRequest(String receiverId) async {
  final currentUserId = Supabase.instance.client.auth.currentUser?.id;
  if (currentUserId == null) {
    print('Kein eingeloggter Nutzer!');
    return;
  }
  if (currentUserId == receiverId) {
    print('Du kannst dir selbst keine Freundschaftsanfrage senden.');
    return;
  }

  final response = await Supabase.instance.client
      .from('friend_requests')
      .insert({
        'requester_id': currentUserId,
        'receiver_id': receiverId,
        'status': 'pending',
      });

  if (response.error != null) {
    print('Fehler beim Senden der Anfrage: ${response.error!.message}');
  } else {
    print('Freundschaftsanfrage gesendet!');
  }
}



  Future<List<dynamic>> getCommentsForPost(int postId) async {
    final response = await Supabase.instance.client
        .from('comments')
        .select()
        .eq('post_id', postId)
        .order('created_at', ascending: true);
    return response;
  }

  @override
  Widget build(BuildContext context) {
    if (profileData == null) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.surface,
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 20),
            // Header
            Row(
              children: [
                const SizedBox(width: 20),
                Text(
                  'tgthr.',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                    color: Theme.of(context).colorScheme.inversePrimary,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            // Scrollbereich
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Center(
                      child: profileData!['avatar_url'] != null
                          ? CircleAvatar(
                              backgroundImage:
                                  NetworkImage(profileData!['avatar_url']),
                              radius: 50,
                            )
                          : const CircleAvatar(
                              child: Icon(Icons.person),
                              radius: 50,
                            ),
                    ),
                    const SizedBox(height: 20),
                    Text(
                      '@${profileData!['username']}',
                      style: const TextStyle(
                          fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      'Lieblingssport: ${profileData!['favorite_sport'] ?? 'Nicht angegeben'}',
                      style: const TextStyle(fontSize: 16),
                    ),
                    const SizedBox(height: 20),
                    ElevatedButton(
                      onPressed: () {
                        sendFriendRequest(widget.userId);
                      },
                      child: const Text('Freundschaftsanfrage senden'),
                    ),
                    const SizedBox(height: 30),
                    const Divider(thickness: 1),
                    const SizedBox(height: 10),
                    Text(
                      'Beiträge von ${profileData!['username']}',
                      style: const TextStyle(
                          fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 10),
                    GridView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: userPosts.length,
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 3,
                        crossAxisSpacing: 5,
                        mainAxisSpacing: 5,
                      ),
                      itemBuilder: (context, index) {
                        final post = userPosts[index];
                        final imageUrl = post['image_url'];
                        final postId = post['id'];

                        return GestureDetector(
                          onTap: () {
                            showDialog(
                              context: context,
                              barrierColor: Colors.black.withOpacity(0.5),
                              builder: (BuildContext context) {
                                return Dialog(
                                  backgroundColor: Colors.transparent,
                                  child: Container(
                                    padding: const EdgeInsets.all(16),
                                    decoration: BoxDecoration(
                                      color:
                                          Theme.of(context).colorScheme.surface,
                                      borderRadius: BorderRadius.circular(20),
                                    ),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(12),
                                          child: Image.network(imageUrl),
                                        ),
                                        const SizedBox(height: 10),
                                        Row(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            const Icon(Icons.favorite,
                                                size: 20),
                                            const SizedBox(width: 6),
                                            Text(
                                              '${post['likes'] ?? 0} Likes',
                                              style:
                                                  const TextStyle(fontSize: 16),
                                            ),
                                          ],
                                        ),
                                        const SizedBox(height: 10),

                                        FutureBuilder<List<dynamic>>(
                                          future: getCommentsForPost(postId),
                                          builder: (context, snapshot) {
                                            if (snapshot.connectionState ==
                                                ConnectionState.waiting) {
                                              return const CircularProgressIndicator();
                                            } else if (snapshot.hasError) {
                                              return const Text(
                                                  'Fehler beim Laden der Kommentare');
                                            }

                                            final comments = snapshot.data ?? [];

                                            if (comments.isEmpty) {
                                              return const Text(
                                                'Keine Kommentare vorhanden',
                                                style: TextStyle(fontSize: 16),
                                              );
                                            }

                                            return Column(
                                              children: comments.map((comment) {
                                                return Align(
                                                  alignment:
                                                      Alignment.centerLeft,
                                                  child: Padding(
                                                    padding: const EdgeInsets
                                                        .symmetric(vertical: 4),
                                                    child: Text(
                                                      '• ${comment['text']}',
                                                      style: const TextStyle(
                                                          fontSize: 14),
                                                    ),
                                                  ),
                                                );
                                              }).toList(),
                                            );
                                          },
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            );
                          },
                           child: ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: Image.network(
                              imageUrl,
                              fit: BoxFit.cover,
                              width: double.infinity,
                              height: double.infinity,
                            ),
                          ),
                        );
                      },
                    ),
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
