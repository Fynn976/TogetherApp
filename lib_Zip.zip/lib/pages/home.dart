import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:loginpage/pages/ProfileForOthers.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:liquid_pull_to_refresh/liquid_pull_to_refresh.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<dynamic> posts = [];
  TextEditingController _commentController = TextEditingController();
  String displayName = '...';

  // Map zum Tracken, welche Posts alle Kommentare anzeigen
  Map<int, bool> _showAllComments = {};

  Future<void> fetchPosts() async {
    final response = await Supabase.instance.client
        .from('posts')
        .select('''
          id,
          image_url,
          caption,
          created_at,
          user_id,
          profiles (
            display_name,
            avatar_url,
            username,
            id
          )
        ''')
        .order('created_at', ascending: false);

    if (response != null) {
      final postsWithLikes = <dynamic>[];

      for (var post in response) {
        final postId = post['id'];
        final likesResponse = await Supabase.instance.client
            .from('likes')
            .select()
            .eq('post_id', postId);

        post['likes'] = likesResponse ?? [];
        postsWithLikes.add(post);
      }

      setState(() {
        posts = postsWithLikes;
      });
    } else {
      print('Fehler beim Laden der Posts: Keine Daten gefunden.');
    }
  }

  Future<void> fetchDisplayName() async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) return;

    try {
      final response = await Supabase.instance.client
          .from('profiles')
          .select('display_name')
          .eq('id', userId)
          .single();

      setState(() {
        displayName = response['display_name'] ?? 'Unbekannt';
      });
    } catch (e) {
      setState(() {
        displayName = 'Unbekannt';
      });
    }
  }

  Future<void> toggleLike(int postId) async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) return;

    final existingLike = await Supabase.instance.client
        .from('likes')
        .select()
        .eq('post_id', postId)
        .eq('user_id', userId)
        .maybeSingle();

    if (existingLike != null) {
      await Supabase.instance.client
          .from('likes')
          .delete()
          .eq('id', existingLike['id']);
    } else {
      await Supabase.instance.client
          .from('likes')
          .insert({'post_id': postId, 'user_id': userId});
    }

    await fetchPosts();
  }

  Future<void> addComment(int postId) async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    final commentText = _commentController.text.trim();

    if (commentText.isEmpty || userId == null) return;

    await Supabase.instance.client.from('comments').insert({
      'post_id': postId,
      'user_id': userId,
      'text': commentText,
    });

    _commentController.clear();
    await fetchPosts();
  }

  @override
  void initState() {
    super.initState();
    fetchPosts();
    fetchDisplayName();
  }

  @override
  Widget build(BuildContext context) {
    final currentUser = Supabase.instance.client.auth.currentUser;
    if (currentUser == null) {
      return Scaffold(
        body: Center(child: Text('Bitte logge dich ein')),
      );
    }

    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.surface,
      body: SafeArea(
        child: LiquidPullToRefresh(
          onRefresh: fetchPosts,
          color: Theme.of(context).colorScheme.primary,
          backgroundColor: Theme.of(context).colorScheme.surface,
          height: 150.0,
          animSpeedFactor: 2.0,
          showChildOpacityTransition: false,
          child: ListView(
            padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 20),
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text(
                    'tgthr.',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                      color: Theme.of(context).colorScheme.inversePrimary,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 25),
              Text(
                'Willkommen, $displayName',
                style: TextStyle(
                  fontWeight: FontWeight.w900,
                  color: Theme.of(context).colorScheme.inversePrimary,
                  fontSize: 30,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                'Bereit für dein nächstes Training?',
                style: TextStyle(
                  fontFamily: GoogleFonts.montserrat().fontFamily,
                  fontWeight: FontWeight.w700,
                  color: Theme.of(context).colorScheme.inversePrimary,
                  fontSize: 15,
                ),
              ),
              const SizedBox(height: 50),
              Text(
                'Hier beginnt dein Feed!',
                style: TextStyle(
                  fontFamily: GoogleFonts.montserrat().fontFamily,
                  fontWeight: FontWeight.w600,
                  color: Theme.of(context).colorScheme.inversePrimary,
                  fontSize: 18,
                ),
              ),
              const SizedBox(height: 20),

              if (posts.isEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 30),
                  child: Text(
                    'Es scheint hier gerade etwas ruhig zu sein...',
                    style: TextStyle(
                      fontFamily: GoogleFonts.montserrat().fontFamily,
                      fontWeight: FontWeight.w500,
                      color: Theme.of(context).colorScheme.inversePrimary,
                      fontSize: 18,
                    ),
                  ),
                )
              else
                ...posts.map((post) {
                  final postId = post['id'];
                  final imageUrl = post['image_url'];
                  final caption = post['caption'] ?? 'Keine Beschreibung';
                  final profile = post['profiles'];
                  final postDisplayName = profile?['display_name'] ?? 'Unbekannt';
                  final avatarUrl = profile?['avatar_url'];
                  final profileId = profile?['id'];
                  final likeList = post['likes'] as List<dynamic>? ?? [];
                  final likeCount = likeList.length;

                  final userId = currentUser.id;
                  final bool isLiked = likeList.any((like) => like['user_id'] == userId);

                  return Card(
                    margin: const EdgeInsets.symmetric(vertical: 10),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                      side: BorderSide(
                        color: Colors.grey.shade300,
                        width: 1,
                      ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(10),
                          child: GestureDetector(
                            onTap: () {
                              if (profileId == null) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(content: Text('Kein Profil verfügbar')),
                                );
                                return;
                              }
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) =>
                                      PublicProfilePage(userId: profileId.toString()),
                                ),
                              );
                            },
                            child: Row(
                              children: [
                                CircleAvatar(
                                  radius: 20,
                                  backgroundImage:
                                      avatarUrl != null ? NetworkImage(avatarUrl) : null,
                                  child: avatarUrl == null ? const Icon(Icons.person) : null,
                                ),
                                const SizedBox(width: 10),
                                Text(
                                  postDisplayName,
                                  style: TextStyle(
                                    fontWeight: FontWeight.w600,
                                    fontFamily: GoogleFonts.montserrat().fontFamily,
                                    fontSize: 16,
                                    color: Theme.of(context).colorScheme.inversePrimary,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            showDialog(
                              context: context,
                              builder: (_) => Dialog(
                                backgroundColor: Colors.black,
                                insetPadding: const EdgeInsets.all(20),
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(12),
                                  child: InteractiveViewer(
                                    child: Image.network(
                                      imageUrl,
                                      fit: BoxFit.contain,
                                    ),
                                  ),
                                ),
                              ),
                            );
                          },
                          child: ClipRRect(
                            borderRadius: const BorderRadius.vertical(
                              top: Radius.circular(20),
                            ),
                            child: AspectRatio(
                              aspectRatio: 1,
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(20),
                                child: Stack(
                                  fit: StackFit.expand,
                                  children: [
                                    Transform.scale(
                                      scale: 1,
                                      child: Image.network(
                                        imageUrl,
                                        fit: BoxFit.fitWidth,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                          child: Row(
                            children: [
                              Expanded(
                                child: Text(
                                  caption,
                                  style: TextStyle(
                                    fontFamily: GoogleFonts.montserrat().fontFamily,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w500,
                                    color: Theme.of(context).colorScheme.inversePrimary,
                                  ),
                                ),
                              ),
                              IconButton(
                                icon: Icon(
                                  isLiked ? Icons.favorite : Icons.favorite_border,
                                  color: isLiked ? Colors.red : null,
                                ),
                                onPressed: () => toggleLike(postId),
                              ),
                              Text('Likes: $likeCount'),
                            ],
                          ),
                        ),
                        const Divider(
                          thickness: 0.5,
                          color: Colors.grey,
                          height: 20,
                        ),
                        FutureBuilder(
                          future: Supabase.instance.client
                              .from('comments')
                              .select('text, profiles(id, display_name, username)')
                              .eq('post_id', postId),
                          builder: (context, snapshot) {
                            if (snapshot.connectionState == ConnectionState.waiting) {
                              return const Padding(
                                padding: EdgeInsets.all(8.0),
                                child: CircularProgressIndicator(),
                              );
                            }
                            if (snapshot.hasError) {
                              return Text('Fehler: ${snapshot.error.toString()}');
                            }

                            final comments = snapshot.data as List<dynamic>? ?? [];

                            if (comments.isEmpty) {
                              return const Padding(
                                padding: EdgeInsets.all(8.0),
                                child: Text('Noch keine Kommentare.'),
                              );
                            }

                            final showAll = _showAllComments[postId] ?? false;
                            final commentsToShow = showAll ? comments : comments.take(1).toList();

                            return Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                ...commentsToShow.map((comment) {
                                  final profile = comment['profiles'];
                                  final authorName =
                                      profile?['display_name'] ?? profile?['username'] ?? 'Unbekannt';
                                  final authorProfileId = profile?['id'];

                                  return ListTile(
                                    title: RichText(
                                      text: TextSpan(
                                        children: [
                                          WidgetSpan(
                                            alignment: PlaceholderAlignment.baseline,
                                            baseline: TextBaseline.alphabetic,
                                            child: GestureDetector(
                                              onTap: () {
                                                if (authorProfileId == null) {
                                                  ScaffoldMessenger.of(context).showSnackBar(
                                                    SnackBar(content: Text('Kein Profil verfügbar')),
                                                  );
                                                  return;
                                                }
                                                Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                    builder: (context) => PublicProfilePage(
                                                        userId: authorProfileId.toString()),
                                                  ),
                                                );
                                              },
                                              child: Text(
                                                '$authorName: ',
                                                style: TextStyle(
                                                  fontWeight: FontWeight.bold,
                                                  color: Theme.of(context).colorScheme.inversePrimary,
                                                  fontSize: 16,
                                                ),
                                              ),
                                            ),
                                          ),
                                          TextSpan(
                                            text: comment['text'],
                                            style: TextStyle(
                                              color: Theme.of(context).colorScheme.inversePrimary,
                                              fontSize: 16,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  );
                                }).toList(),

                                if (comments.length > 1)
                                  Align(
                                    alignment: Alignment.center,
                                    child: IntrinsicWidth(
                                      child: TextButton(
                                        onPressed: () {
                                          setState(() {
                                            _showAllComments[postId] = !showAll;
                                          });
                                        },
                                        style: TextButton.styleFrom(
                                          backgroundColor: Theme.of(context).colorScheme.inversePrimary,
                                        ),
                                        child: Text(showAll ? 'Weniger anzeigen' : 'Mehr anzeigen'),
                                      ),
                                    ),
                                  ),

                              ],
                            );
                          },
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: TextField(
                            controller: _commentController,
                            decoration: InputDecoration(
                              hintText: 'Füge einen Kommentar hinzu...',
                              suffixIcon: IconButton(
                                icon: const Icon(Icons.send),
                                onPressed: () => addComment(postId),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                }).toList(),
            ],
          ),
        ),
      ),
    );
  }
}
