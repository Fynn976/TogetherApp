import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'dart:io';

class ImageEvents extends StatefulWidget {
  final Function(List<String>) onImagesChanged; // Callback für Liste der URLs

  const ImageEvents({super.key, required this.onImagesChanged});

  @override
  State<ImageEvents> createState() => _ImageEventsState();
}

class _ImageEventsState extends State<ImageEvents> {
  final ImagePicker _picker = ImagePicker();


  List<File> _localFiles = [];        // lokal ausgewählte Bilder (für Vorschau)
  List<String> _imageUrls = [];       // URLs aus Supabase (hochgeladen)

  bool _isUploading = false;

  Future<void> _pickAndUploadImage() async {
    final image = await _picker.pickImage(source: ImageSource.gallery);
    if (image == null) return;

    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Du musst eingeloggt sein.")),
      );
      return;
    }

    setState(() {
      _isUploading = true;
    });

    final file = File(image.path);
    final fileExt = image.path.split('.').last;
    final fileName = '${DateTime.now().millisecondsSinceEpoch}.$fileExt';
    final uploadPath = 'events/$userId/$fileName';

    try {
      // Upload in Supabase Storage
      await Supabase.instance.client.storage
          .from('images')
          .upload(uploadPath, file, fileOptions: const FileOptions(upsert: true));

      final publicUrl = Supabase.instance.client.storage
          .from('images')
          .getPublicUrl(uploadPath);

      setState(() {
        _localFiles.add(file);
        _imageUrls.add(publicUrl);
      });

      widget.onImagesChanged(_imageUrls);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Bild erfolgreich hochgeladen.")),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Fehler beim Hochladen: $e")),
      );
    } finally {
      setState(() {
        _isUploading = false;
      });
    }
  }

  Future<void> _deleteImage(int index) async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Du musst eingeloggt sein.")),
      );
      return;
    }

    final url = _imageUrls[index];

    // Den Pfad aus der URL extrahieren
    final storageBaseUrl = Supabase.instance.client.storage.from('images').getPublicUrl('');
    final filePath = url.replaceFirst(storageBaseUrl, '');

    try {
      await Supabase.instance.client.storage.from('images').remove([filePath]);

      setState(() {
        _localFiles.removeAt(index);
        _imageUrls.removeAt(index);
      });

      widget.onImagesChanged(_imageUrls);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Bild erfolgreich gelöscht.")),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Fehler beim Löschen: $e")),
      );
    }
  }

  void _showPickImageDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'Bild auswählen',
          style: TextStyle(
            color: Theme.of(context).colorScheme.inversePrimary,
            fontWeight: FontWeight.w500,
          ),
        ),
        content: Text(
          'Möchtest du ein Bild auswählen?',
          style: TextStyle(
            color: Theme.of(context).colorScheme.inversePrimary,
            fontWeight: FontWeight.w400,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              _pickAndUploadImage();
            },
            child: Text('Ja', style: TextStyle(color: Theme.of(context).colorScheme.primary)),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text('Nein', style: TextStyle(color: Theme.of(context).colorScheme.primary)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 120,
          child: _imageUrls.isEmpty
              ? GestureDetector(
                  onTap: _showPickImageDialog,
                  child: Container(
                    width: 100,
                    height: 100,
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.primary,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Center(
                      child: _isUploading
                          ? CircularProgressIndicator(color: Theme.of(context).colorScheme.inversePrimary)
                          : Icon(
                              Icons.add_a_photo,
                              color: Theme.of(context).colorScheme.inversePrimary,
                              size: 50,
                            ),
                    ),
                  ),
                )
              : ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: _imageUrls.length + 1,
                  itemBuilder: (context, index) {
                    if (index == _imageUrls.length) {
                      // Button zum neues Bild hinzufügen
                      return Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 8),
                        child: GestureDetector(
                          onTap: _isUploading ? null : _showPickImageDialog,
                          child: Container(
                            width: 100,
                            height: 100,
                            decoration: BoxDecoration(
                              color: _isUploading ? Colors.grey : Theme.of(context).colorScheme.primary,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Center(
                              child: _isUploading
                                  ? CircularProgressIndicator(color: Theme.of(context).colorScheme.inversePrimary)
                                  : Icon(
                                      Icons.add_a_photo,
                                      color: Theme.of(context).colorScheme.inversePrimary,
                                      size: 50,
                                    ),
                            ),
                          ),
                        ),
                      );
                    }

                    return Stack(
                      children: [
                        Container(
                          margin: const EdgeInsets.symmetric(horizontal: 8),
                          width: 400,
                          height: 400,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12),
                            image: DecorationImage(
                              image: NetworkImage(_imageUrls[index]),
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                        Positioned(
                          top: 4,
                          right: 4,
                          child: GestureDetector(
                            onTap: () => _deleteImage(index),
                            child: Container(
                              decoration: BoxDecoration(
                                color: Colors.black54,
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(
                                Icons.close,
                                color: Colors.white,
                                size: 20,
                              ),
                            ),
                          ),
                        ),
                      ],
                    );
                  },
                ),
        ),
      ],
    );
  }
}
