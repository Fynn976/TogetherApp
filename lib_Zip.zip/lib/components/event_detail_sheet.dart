import 'package:flutter/material.dart';
import 'package:loginpage/components/EventMap.dart';
import 'package:intl/intl.dart';

class EventDetailSheet extends StatefulWidget {
  final Map<String, dynamic> event;
  final VoidCallback onJoin;

  const EventDetailSheet({
    Key? key,
    required this.event,
    required this.onJoin,
  }) : super(key: key);

  @override
  State<EventDetailSheet> createState() => _EventDetailSheetState();
}

class _EventDetailSheetState extends State<EventDetailSheet> {
  int _currentPage = 0;

  @override
  Widget build(BuildContext context) {
    final event = widget.event;
    final List<String> imageUrls = (event['image_urls'] as List<dynamic>?)?.cast<String>() ?? [];
    final double latitude = (event['latitude'] as num?)?.toDouble() ?? 0;
    final double longitude = (event['longitude'] as num?)?.toDouble() ?? 0;

    // ✅ Formatierung vor dem Widget-Baum
    String formattedDate = 'Kein Datum verfügbar';

final rawDate = event['time_and_date'];
DateTime? parsedDate;

 if (rawDate != null) {
      if (rawDate is String && rawDate.isNotEmpty) {
        // Versuche ISO8601 Parse
        parsedDate = DateTime.tryParse(rawDate);
        if (parsedDate == null) {
          // Optional: Format 'yyyy-MM-dd HH:mm:ss'
          try {
            parsedDate = DateFormat('yyyy-MM-dd HH:mm:ss').parseStrict(rawDate);
          } catch (_) {
            // parsing failed, null lassen
          }
        }
      } else if (rawDate is DateTime) {
        parsedDate = rawDate;
      }
    }

 if (parsedDate != null) {
      formattedDate = DateFormat('EEEE, d. MMMM yyyy – HH:mm', 'de_DE')
          .format(parsedDate.toLocal());
    }

    print("Datum aus Event: $rawDate");
    print("Kompletter Event-Inhalt: $event");
    print("Datum aus Event: ${event['time_and_date']}");

    return Scaffold(
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Divider(
              color: Theme.of(context).colorScheme.primary,
              thickness: 4,
              indent: 150,
              endIndent: 150,
            ),
            const SizedBox(height: 16),

            if (imageUrls.isNotEmpty)
              LayoutBuilder(
                builder: (context, constraints) {
                  final double imageSize = MediaQuery.of(context).size.width * 0.8;
                  return Column(
                    children: [
                      Center(
                        child: SizedBox(
                          width: 400,
                          height: 400,
                          child: PageView.builder(
                            itemCount: imageUrls.length,
                            onPageChanged: (index) {
                              setState(() {
                                _currentPage = index;
                              });
                            },
                            itemBuilder: (context, index) {
                              return ClipRRect(
                                borderRadius: BorderRadius.circular(12),
                                child: Image.network(
                                  imageUrls[index],
                                  fit: BoxFit.cover,
                                  errorBuilder: (context, error, stackTrace) =>
                                      const Icon(Icons.image_not_supported, size: 48),
                                ),
                              );
                            },
                          ),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: List.generate(imageUrls.length, (index) {
                          return Container(
                            width: 8,
                            height: 8,
                            margin: const EdgeInsets.symmetric(horizontal: 4),
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: _currentPage == index
                                  ? Theme.of(context).colorScheme.inversePrimary
                                  : Theme.of(context).colorScheme.inversePrimary.withOpacity(0.3),
                            ),
                          );
                        }),
                      ),
                    ],
                  );
                },
              )
            else
              Center(
                child: Container(
                  height: 400,
                  width: 400,
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.image_not_supported,
                          size: 48, color: Theme.of(context).colorScheme.inversePrimary),
                      const SizedBox(height: 8),
                      Text(
                        "Keine Bilder verfügbar",
                        style: TextStyle(
                            color: Theme.of(context).colorScheme.inversePrimary, fontSize: 16),
                      ),
                    ],
                  ),
                ),
              ),

            const SizedBox(height: 16),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10.0),
              child: Text(
                event['title'] ?? 'Kein Titel',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
            ),
            const SizedBox(height: 8),

            // ✅ Datumsanzeige korrekt
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10.0),
              child: Text(
                formattedDate,
                style: const TextStyle(fontSize: 12),
              ),
            ),

            const SizedBox(height: 16),
            Center(
              child: GestureDetector(
                onTap: widget.onJoin,
                child: Container(
                  padding: const EdgeInsets.all(10.0),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primary,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.group_add,
                          color: Theme.of(context).colorScheme.inversePrimary),
                      const SizedBox(width: 8),
                      Text(
                        "Beitreten",
                        style: TextStyle(
                            fontSize: 16,
                            color: Theme.of(context).colorScheme.inversePrimary),
                      )
                    ],
                  ),
                ),
              ),
            ),

            const SizedBox(height: 16),
            Card(
              margin: const EdgeInsets.symmetric(vertical: 10.0),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0),
                side: BorderSide(
                  color: Theme.of(context).colorScheme.primary,
                  width: 1.0,
                ),
              ),
              child: ListTile(
                title: Text("Beschreibung",
                    style: Theme.of(context).textTheme.titleMedium),
                subtitle: Text(event['description'] ?? '-'),
              ),
            ),
            const SizedBox(height: 16),
            Card(
              margin: const EdgeInsets.symmetric(vertical: 10.0),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0),
                side: BorderSide(
                  color: Theme.of(context).colorScheme.primary,
                  width: 1.0,
                ),
              ),
              child: ListTile(
                title: Text("Sportart",
                    style: Theme.of(context).textTheme.titleMedium),
                subtitle: Text(event['sport'] ?? '-'),
              ),
            ),
            const SizedBox(height: 16),
            Text("Ort", style: Theme.of(context).textTheme.titleMedium),
            Divider(color: Theme.of(context).colorScheme.primary, thickness: 1),
            Text(event['location'] ?? '-'),
            SizedBox(
              height: 150,
              width: double.infinity,
              child: EventMap(
                latitude: latitude,
                longitude: longitude,
              ),
            ),
            const SizedBox(height: 16),
            Text("Teilnehmer", style: Theme.of(context).textTheme.titleMedium),
            Text("${event['current_participants'] ?? 0} / ${event['max_participants'] ?? '-'}"),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}
